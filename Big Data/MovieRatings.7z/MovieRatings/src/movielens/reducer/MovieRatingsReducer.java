package movielens.reducer;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import movielens.domain.TextPair;

public class MovieRatingsReducer extends Reducer<LongWritable, TextPair, Text, LongWritable> {
	public void reduce(LongWritable key, Iterable<TextPair> values, Context context) throws IOException, InterruptedException {
		System.out.println("Key: " + key);		
		Iterator<TextPair> iterator = values.iterator();
		Text movieName = null;
		int ratingsCount = 0;
		while (iterator.hasNext()) {
			TextPair text = iterator.next();
			if(text.getFirst().toString().equalsIgnoreCase("Movie")) {
				movieName = new Text(text.getSecond());
			} else {
				ratingsCount++;
			}						
		}
		System.out.println(ratingsCount);
		context.write(movieName, new LongWritable(ratingsCount));
	}
}
