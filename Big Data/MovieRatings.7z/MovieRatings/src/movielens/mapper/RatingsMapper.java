package movielens.mapper;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import movielens.domain.TextPair;

public class RatingsMapper extends Mapper<LongWritable, Text, LongWritable, TextPair> {
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		String valueString = value.toString();
		String[] singleRatingData = valueString.split(",");
		System.out.println(singleRatingData[1]);
		if(singleRatingData[1].equalsIgnoreCase("movieId"))
			return;
		context.write(new LongWritable(Long.parseLong(singleRatingData[1])), new TextPair("Rating", singleRatingData[2]));
	}
}
