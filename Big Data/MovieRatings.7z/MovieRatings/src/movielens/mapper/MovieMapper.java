package movielens.mapper;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import movielens.domain.TextPair;

public class MovieMapper extends Mapper<LongWritable, Text, LongWritable, TextPair> {
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {		
		String valueString = value.toString();
		String[] singleMovieData = valueString.split(",");
		System.out.println(singleMovieData[0]);
		if(singleMovieData[0].equalsIgnoreCase("movieId"))
			return;
		context.write(new LongWritable(Long.parseLong(singleMovieData[0])), new TextPair("Movie", singleMovieData[1]));
	}
}