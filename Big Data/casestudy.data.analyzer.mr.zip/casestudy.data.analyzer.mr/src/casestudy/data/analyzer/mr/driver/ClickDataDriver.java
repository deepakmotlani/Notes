package casestudy.data.analyzer.mr.driver;

import java.io.IOException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import casestudy.data.analyzer.mr.mapper.ClickDataMapper;
import casestudy.data.analyzer.mr.reducer.ClickDataReducer;

public class ClickDataDriver {

    public static void main(String[] args) throws IOException, InterruptedException, ClassNotFoundException {       
        JobConf jobConf = new JobConf();
        Job job = Job.getInstance(jobConf, "Click Data Analyzer");
        
        job.setJarByClass(ClickDataDriver.class);
        job.setMapperClass(ClickDataMapper.class);
        job.setReducerClass(ClickDataReducer.class);
        
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(LongWritable.class);
        job.setOutputKeyClass(NullWritable.class);
        job.setOutputValueClass(Text.class);
        
        FileInputFormat.addInputPath(job, new Path(args[1]));
        FileOutputFormat.setOutputPath(job, new Path(args[2]));
        
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }

}
