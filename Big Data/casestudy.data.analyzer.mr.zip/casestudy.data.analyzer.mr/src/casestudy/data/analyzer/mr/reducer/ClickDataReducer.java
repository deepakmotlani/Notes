package casestudy.data.analyzer.mr.reducer;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.json.JSONException;
import org.json.JSONObject;

public class ClickDataReducer
        extends Reducer<Text, LongWritable, NullWritable, Text> {
    
    @Override
    public void reduce(Text key, Iterable<LongWritable> values, Context context)
            throws IOException, InterruptedException {
        Iterator<LongWritable> itr = values.iterator();
        int count = 0;
        while (itr.hasNext()) {
            count++;
        }
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("page", key);
            jsonObject.put("count", count);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        
        context.write(NullWritable.get(), new Text(jsonObject.toString()));
    }
}