package com.hive.udf;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.hadoop.hive.ql.exec.UDF;

public class BirthSeason extends UDF {
    private SimpleDateFormat dateFormat;
    
    public BirthSeason() {
    	dateFormat = new SimpleDateFormat("dd-MM-yyyy");
    }
    
    public String evaluate(String dob) throws ParseException {
    	Date date = dateFormat.parse(dob);
    	if(date.getMonth() >= 3 && date.getMonth() <= 6)
    		return "Summers";
    	if(date.getMonth() >= 7 && date.getMonth() <= 10)
    		return "Rainy";
    	if((date.getMonth() >= 11 && date.getMonth() <= 12) || (date.getMonth() >= 1 && date.getMonth() <= 2))
    		return "Winters";
    	return null;
    }
}
