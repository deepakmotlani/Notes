package com.hive.udf.aggregate;

import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.hive.ql.exec.UDFArgumentTypeException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.parse.SemanticException;
import org.apache.hadoop.hive.ql.udf.generic.AbstractGenericUDAFResolver;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFEvaluator;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFParameterInfo;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDAFEvaluator.Mode;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorUtils;
import org.apache.hadoop.hive.serde2.objectinspector.PrimitiveObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.StandardListObjectInspector;

public class GenricUDAFCollect extends AbstractGenericUDAFResolver {

	public GenricUDAFCollect() {

	}

	@Override
	public GenericUDAFEvaluator getEvaluator(GenericUDAFParameterInfo info) throws SemanticException {
		if (info.getParameters().length != 1) {
			throw new UDFArgumentTypeException(info.getParameters().length - 1, "Exactly one argument is expected.");
		}
		if (info.getParameters()[0].getCategory() != ObjectInspector.Category.PRIMITIVE) {
			throw new UDFArgumentTypeException(0, "Only primitive type arguments are accepted but "
					+ info.getParameters()[0].getTypeName() + " was passed as parameter 1.");
		}
		return new GenericUDAFListEvaluator();
	}

	public static class GenericUDAFListEvaluator extends GenericUDAFEvaluator {

		private PrimitiveObjectInspector inputOI;
		private StandardListObjectInspector loi;
		private StandardListObjectInspector internalMergeOI;

		public ObjectInspector init(Mode m, ObjectInspector[] parameters) throws HiveException {
			super.init(m, parameters);

			if (m == Mode.PARTIAL1) {
				inputOI = (PrimitiveObjectInspector) parameters[0];
				return ObjectInspectorFactory.getStandardListObjectInspector(
						(PrimitiveObjectInspector) ObjectInspectorUtils.getStandardObjectInspector(inputOI));
			} else {
				if (!(parameters[0] instanceof StandardListObjectInspector)) {
					inputOI = (PrimitiveObjectInspector) ObjectInspectorUtils.getStandardObjectInspector(parameters[0]);
					return (StandardListObjectInspector) ObjectInspectorFactory.getStandardListObjectInspector(inputOI);
				} else {
					internalMergeOI = (StandardListObjectInspector) parameters[0];
					inputOI = (PrimitiveObjectInspector) internalMergeOI.getListElementObjectInspector();
					loi = (StandardListObjectInspector) ObjectInspectorUtils
							.getStandardObjectInspector(internalMergeOI);
					return loi;
				}
			}
		}

		static class MkArrayAggregationBuffer implements AggregationBuffer {
			List<Object> container;
		}

		@Override
		public AggregationBuffer getNewAggregationBuffer() throws HiveException {
			MkArrayAggregationBuffer buffer = new MkArrayAggregationBuffer();
			reset(buffer);
			return buffer;
		}

		@Override
		public void reset(AggregationBuffer agg) throws HiveException {
			((MkArrayAggregationBuffer) agg).container = new ArrayList<Object>();
		}

		@Override
		public void iterate(AggregationBuffer agg, Object[] parameters) throws HiveException {
			assert (parameters.length == 1);
			Object p = parameters[0];
			if (p != null) {
				MkArrayAggregationBuffer myagg = (MkArrayAggregationBuffer) agg;
				putIntoList(p, myagg);
			}
		}

		@Override
		public Object terminatePartial(AggregationBuffer agg) throws HiveException {
			MkArrayAggregationBuffer buffer = (MkArrayAggregationBuffer) agg;
			ArrayList<Object> ret = new ArrayList<Object>(buffer.container.size());
			ret.addAll(buffer.container);
			return ret;
		}

		@Override
		public void merge(AggregationBuffer agg, Object partial) throws HiveException {
			MkArrayAggregationBuffer myagg = (MkArrayAggregationBuffer) agg;
			ArrayList<Object> partialResult = (ArrayList<Object>) internalMergeOI.getList(partial);
			for (Object i : partialResult) {
				putIntoList(i, myagg);
			}
		}

		@Override
		public Object terminate(AggregationBuffer agg) throws HiveException {
			MkArrayAggregationBuffer myagg = (MkArrayAggregationBuffer) agg;
			ArrayList<Object> ret = new ArrayList<Object>(myagg.container.size());
			ret.addAll(myagg.container);
			return ret;
		}

		private void putIntoList(Object p, MkArrayAggregationBuffer myagg) {
			Object pCopy = ObjectInspectorUtils.copyToStandardObject(p, this.inputOI);
			myagg.container.add(pCopy);
		}
	}
}
