package com.deepak.spark.rtb.mllib;

import java.util.Arrays;
import java.util.List;

import org.apache.spark.ml.feature.CountVectorizer;
import org.apache.spark.ml.feature.CountVectorizerModel;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.ArrayType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

public class CountVectorizerProgram {
    public static void main(String[] args) {
        SparkSession spark = SparkSession.builder()
                .config("spark.sql.warehouse.dir",
                        "hdfs://localhost:54310/user/hive/warehouse")
                .appName("Spark MLlib").getOrCreate();
        spark.sparkContext().setLogLevel("WARN");
        
        List<Row> data = Arrays.asList(
                RowFactory.create(Arrays.asList("a", "b", "c")),
                RowFactory.create(Arrays.asList("a", "b", "b", "c", "a", "d")));
        StructType schema = new StructType(
                new StructField[] { new StructField("text",
                        new ArrayType(DataTypes.StringType, true), false,
                        Metadata.empty()) });
        Dataset<Row> df = spark.createDataFrame(data, schema);

        // fit a CountVectorizerModel from the corpus
        CountVectorizerModel cvModel = new CountVectorizer().setInputCol("text")
                .setOutputCol("feature").setVocabSize(4).setMinDF(1).fit(df);

        cvModel.transform(df).show(false);
    }
}
