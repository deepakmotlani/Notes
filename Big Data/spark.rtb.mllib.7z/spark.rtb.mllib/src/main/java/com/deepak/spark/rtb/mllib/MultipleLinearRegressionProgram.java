package com.deepak.spark.rtb.mllib;

import org.apache.spark.ml.feature.OneHotEncoderEstimator;
import org.apache.spark.ml.feature.StringIndexer;
import org.apache.spark.ml.feature.VectorAssembler;
import org.apache.spark.ml.regression.LinearRegression;
import org.apache.spark.ml.regression.LinearRegressionModel;
import org.apache.spark.ml.regression.LinearRegressionSummary;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

public class MultipleLinearRegressionProgram {
    public static void main(String[] args) {
        SparkSession spark = SparkSession.builder()
                .config("spark.sql.warehouse.dir",
                        "hdfs://localhost:54310/user/hive/warehouse")
                .appName("Spark MLlib").getOrCreate();
        spark.sparkContext().setLogLevel("WARN");
        StructType schema = new StructType(new StructField[] {
            new StructField("Miscellaneous_Expenses", DataTypes.FloatType, false, Metadata.empty()),
            new StructField("Food_Innovation_Spend", DataTypes.FloatType, false, Metadata.empty()),
            new StructField("Advertising", DataTypes.FloatType, false, Metadata.empty()),
            new StructField("City", DataTypes.StringType, false, Metadata.empty()),
            new StructField("Profit", DataTypes.FloatType, false, Metadata.empty())
        });
        
        Dataset<Row> rows = spark.read().option("header", "true").schema(schema)
            .csv("file:///home/hadoop/mllib/Restaurant-Profit.csv");
        rows.printSchema();
        StringIndexer stringIndexer = new StringIndexer().setInputCol("City").setOutputCol("CityIndex");
        rows = stringIndexer.fit(rows).transform(rows);
        
        OneHotEncoderEstimator oneHotEncoderEstimator = new OneHotEncoderEstimator()
                .setInputCols(new String[] {"CityIndex"})
                .setOutputCols(new String[] {"CityVector"});
        rows = oneHotEncoderEstimator.fit(rows).transform(rows);
        
        VectorAssembler vectorAssembler = new VectorAssembler().setInputCols(new String[] {"Miscellaneous_Expenses",
                "Food_Innovation_Spend", "Advertising", "CityVector"}).setOutputCol("features");
        rows = vectorAssembler.transform(rows);
        
        Dataset<Row>[] splits = rows.randomSplit(new double[] {0.7, 0.3});
        
        LinearRegression linearRegression = new LinearRegression()
                .setFeaturesCol("features").setLabelCol("Profit")
                .setMaxIter(10).setRegParam(0.3);
        
        LinearRegressionModel linearRegressionModel = linearRegression.fit(splits[0]);
        
        LinearRegressionSummary summary = linearRegressionModel.evaluate(splits[1]);
        
        summary.predictions().show();
    }
}
