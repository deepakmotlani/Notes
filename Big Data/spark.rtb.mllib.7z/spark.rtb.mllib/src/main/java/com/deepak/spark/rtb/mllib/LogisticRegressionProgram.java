package com.deepak.spark.rtb.mllib;

import java.util.HashMap;
import java.util.Map;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.mllib.classification.LogisticRegressionModel;
import org.apache.spark.mllib.classification.LogisticRegressionWithLBFGS;
import org.apache.spark.mllib.evaluation.MulticlassMetrics;
import org.apache.spark.mllib.linalg.Vector;
import org.apache.spark.mllib.linalg.Vectors;
import org.apache.spark.mllib.regression.LabeledPoint;

import scala.Tuple2;

public class LogisticRegressionProgram {
    public static void main(String[] args) {
        SparkConf sparkConf = new SparkConf().setMaster("local")
                .setAppName("Word Count");
        JavaSparkContext sparkContext = new JavaSparkContext(sparkConf);

        JavaRDD<String> data = sparkContext.textFile(
                "file:///home/hadoop/mllib/iris.data");

       /* JavaRDD<Vector> inputData = data.map(line -> {
            String[] parts = line.split(",");
            double[] v = new double[parts.length - 1];
            for (int i = 0; i < parts.length - 1; i++) {
                v[i] = Double.parseDouble(parts[i]);
            }
            return Vectors.dense(v);
        });
        System.out.println(inputData);*/
        
        Map<String, Integer> map = new HashMap<>();
        map.put("Iris-setosa", 0);
        map.put("Iris-versicolor", 1);
        map.put("Iris-virginica", 2);
                
        JavaRDD<LabeledPoint> labeledData = data
          .map(line -> {
              String[] parts = line.split(",");
              double[] v = new double[parts.length - 1];
              for (int i = 0; i < parts.length - 1; i++) {
                  v[i] = Double.parseDouble(parts[i]);
              }
              System.out.println(parts[parts.length - 1]);
              return new LabeledPoint(map.get(parts[parts.length - 1]), Vectors.dense(v));
        });
        
        JavaRDD<LabeledPoint>[] splits = labeledData.randomSplit(new double[] { 0.8, 0.2 }, 11L);
        JavaRDD<LabeledPoint> trainingData = splits[0];
        JavaRDD<LabeledPoint> testData = splits[1];
        
        LogisticRegressionModel model = new LogisticRegressionWithLBFGS()
                .setNumClasses(3)
                .run(trainingData.rdd());
        
        JavaPairRDD<Object, Object> predictionAndLabels = testData
                .mapToPair(p -> new Tuple2<>(model.predict(p.features()), p.label()));
        MulticlassMetrics metrics = new MulticlassMetrics(predictionAndLabels.rdd());
        double accuracy = metrics.accuracy();
        System.out.println("Model Accuracy on Test Data: " + accuracy);
        
        model.save(sparkContext.sc(), "file:///home/hadoop/mllib/logistic-regression-model");
        LogisticRegressionModel sameModel = LogisticRegressionModel
          .load(sparkContext.sc(), "file:///home/hadoop/mllib/logistic-regression-model");
        Vector newData = Vectors.dense(new double[]{1,1,1,1});
        double prediction = sameModel.predict(newData);
        System.out.println("Model Prediction on New Data = " + prediction);
        
        sparkContext.close();
    }
}
