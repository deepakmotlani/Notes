package com.deepak.spark.sql;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.SparkSession;

public class DatasourceTest {

	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir", "D:\\spark-2.4.5-bin-hadoop2.7");

		SparkSession session = SparkSession.builder().master("local").appName("Java SQL UADF").getOrCreate();
		session.sparkContext().setLogLevel("WARN");

		Dataset<Row> memberDF = session.read().format("json").option("multiline", true)
				.load("C:\\Users\\deepak.motlani\\Desktop\\Members.json");
		
		memberDF.show();
		
		memberDF.select("id", "name", "age").write().format("parquet").mode(SaveMode.Overwrite)
				.save("C:\\Users\\deepak.motlani\\Desktop\\Members.parquet");
		
		session.sql("SELECT * FROM parquet.`C:\\Users\\deepak.motlani\\Desktop\\Members.parquet`"
						+ "WHERE id = 1").show();;
		
		session.sql("SELECT * FROM text.`C:\\Users\\deepak.motlani\\Desktop\\Members`").show();
		
		session.sql("SELECT * FROM json.`C:\\Users\\deepak.motlani\\Desktop\\Members-Single-Line.json`"
				+ "WHERE id = 2").show();
	}
}
