package com.deepak.spark.structured.streaming;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.streaming.StreamingQuery;
import org.apache.spark.sql.streaming.StreamingQueryException;
import org.apache.spark.sql.streaming.Trigger;
import org.apache.spark.streaming.Duration;

public class StreamStreamJoin {
	public static class Ad {
		private int id;
		private String product;
		private Timestamp adTime;
		
		public Timestamp getAdTime() {
			return adTime;
		}
		public void setAdTime(Timestamp adTime) {
			this.adTime = adTime;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getProduct() {
			return product;
		}
		public void setProduct(String product) {
			this.product = product;
		}
		public Ad(int id, String product, Timestamp adTime) {
			super();
			this.id = id;
			this.product = product;
			this.adTime = adTime;
		}
		
	}

	public static class Click {
		private int adId;
		private String userName;
		private Timestamp clickTime;
		
		public Timestamp getClickTime() {
			return clickTime;
		}
		public void setClickTime(Timestamp clickTime) {
			this.clickTime = clickTime;
		}
		public int getAdId() {
			return adId;
		}
		public void setAdId(int adId) {
			this.adId = adId;
		}
		public String getUserName() {
			return userName;
		}
		public void setUserName(String userName) {
			this.userName = userName;
		}
		public Click(int adId, String userName, Timestamp clickTime) {
			super();
			this.adId = adId;
			this.userName = userName;
			this.clickTime = clickTime;
		}
	}
	
	@SuppressWarnings("serial")
	public static void main(String[] args) throws StreamingQueryException {
		System.setProperty("hadoop.home.dir", "D:\\spark-2.4.5-bin-hadoop2.7");
		SparkSession session = SparkSession.builder().master("local").appName("Stream Stream Join").getOrCreate();
		session.sparkContext().setLogLevel("WARN");
		Dataset<Row> ads = session.readStream().format("socket").option("host", "172.29.44.63").option("port", 9999)
				.load();

		Dataset<Ad> adDF = ads.as(Encoders.STRING()).map(new MapFunction<String, Ad>() {
			@Override
			public Ad call(String value) throws Exception {
				String[] parts = value.split(",");
				Calendar calendar = Calendar.getInstance();
				calendar.set(2020, 5, 26, Integer.parseInt(parts[2].split(":")[0]), Integer.parseInt(parts[2].split(":")[1]));
				return new Ad(Integer.parseInt(parts[0]), parts[1], new Timestamp(calendar.getTime().getTime()));
			}
		}, Encoders.bean(Ad.class));
		
		Dataset<Ad> adDFWithWaterMark = adDF.withWatermark("adTime", "2 minutes");
		
		Dataset<Row> clicks = session.readStream().format("socket").option("host", "172.29.44.63").option("port", 7777)
				.load();

		Dataset<Click> clickDF = clicks.as(Encoders.STRING()).map(new MapFunction<String, Click>() {
			@Override
			public Click call(String value) throws Exception {
				String[] parts = value.split(",");
				Calendar calendar = Calendar.getInstance();
				calendar.set(2020, 5, 26, Integer.parseInt(parts[2].split(":")[0]), Integer.parseInt(parts[2].split(":")[1]));
				return new Click(Integer.parseInt(parts[0]), parts[1], new Timestamp(calendar.getTime().getTime()));
			}
		}, Encoders.bean(Click.class));
		
		Dataset<Click> clickDFWithWaterMark = clickDF.withWatermark("clickTime", "3 minutes");
		
		Dataset<Row> joinedRows =  adDFWithWaterMark.join(clickDFWithWaterMark, 
				adDF.col("id").equalTo(clickDF.col("adId")));
		
		StreamingQuery query = joinedRows.writeStream().outputMode("append").format("console").start();

		query.awaitTermination();
	}
}
