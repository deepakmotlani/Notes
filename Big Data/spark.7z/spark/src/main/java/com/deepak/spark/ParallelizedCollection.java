package com.deepak.spark;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

public class ParallelizedCollection {
	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir","D:\\spark-2.4.5-bin-hadoop2.7" );
		SparkConf sparkConf = new SparkConf().setMaster("local").setAppName("Word Count");
		JavaSparkContext sparkContext = new JavaSparkContext(sparkConf);
		
		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 21, 22, 23, 24, 25);
		JavaRDD<Integer> numbersRDD = sparkContext.parallelize(numbers, 4);
		
		Integer sum = numbersRDD.aggregate(0, (a, b) -> Math.max(a, b), (a, b) -> a + b);
		System.out.println(numbersRDD.getNumPartitions());
		Integer sum1 = numbersRDD.fold(10, (a, b) -> a+b);
		numbersRDD.foreachPartition(x -> x.forEachRemaining(System.out::println));
		System.out.println(sum1);
		System.out.println(numbersRDD.getCheckpointFile());
		
		//numbersRDD.saveAsTextFile("file:///D:/sample-data/numbers");
		
		JavaPairRDD<Boolean, Iterable<Integer>> evenOdd = numbersRDD.groupBy(x -> x % 2 == 0);
		evenOdd.foreach(pair -> {
			System.out.println(pair);
		});
		
		JavaPairRDD<String, Integer> keyByRDD = numbersRDD.keyBy(x -> x%2==0?"even":"odd");
		
		JavaPairRDD<String, Integer> mappedValues = keyByRDD.mapValues(value -> value + 10);
		
		System.out.println("*********** mappedValues **************");
		mappedValues.foreach(value -> {
			System.out.println(value);
		});
		
		keyByRDD.foreach(pair -> {
			System.out.println(pair);
		});
		
		JavaRDD<Integer> increasedNumbersRDD = numbersRDD.mapPartitions(iter -> {
			List<Integer> newList = new ArrayList<>();
			while(iter.hasNext()) {
				newList.add(iter.next() + 10);
			}
			return newList.iterator();
		});
		
		
		
		increasedNumbersRDD.foreach(pair -> {
			System.out.println(pair);
		});
		
		System.out.println(increasedNumbersRDD.toString());
	}
}
