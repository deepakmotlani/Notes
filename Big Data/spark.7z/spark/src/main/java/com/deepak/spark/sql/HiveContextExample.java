package com.deepak.spark.sql;

import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.hive.HiveContext;

public class HiveContextExample {
	public static void main(String[] args) {
		SparkSession session = SparkSession.builder().appName("Hive Spark App").enableHiveSupport().getOrCreate();
		HiveContext hiveContext = new HiveContext(session);
	}
}
