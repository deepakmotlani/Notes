package com.deepak.spark;

import java.io.Serializable;
import java.util.Arrays;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;

import scala.Tuple2;

public class PairRDD {

	public static class Pair implements Serializable {
		private int id;
		private String value;
		public Pair(int id, String value) {
			super();
			this.id = id;
			this.value = value;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getValue() {
			return value;
		}
		public void setValue(String value) {
			this.value = value;
		}
		
	}
	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir", "D:\\spark-2.4.5-bin-hadoop2.7");
		SparkConf sparkConf = new SparkConf().setMaster("local").setAppName("Word Count");
		JavaSparkContext sparkContext = new JavaSparkContext(sparkConf);

		JavaPairRDD<Integer, String> fruitsRdd = sparkContext.parallelize(Arrays.asList(new Pair(1, "Mango"), new Pair(2, "Orange"), new Pair(3, "Watermelon")), 2)
				.mapToPair(pair -> new Tuple2(pair.getId(), pair.getValue()));
		JavaPairRDD<Integer, String> citiesRdd = sparkContext.parallelize(Arrays.asList(new Pair(1, "Indore"), new Pair(2, "Mumbai"), new Pair(3, "Delhi")))
				.mapToPair(pair -> new Tuple2(pair.getId(), pair.getValue()));
	
		 JavaPairRDD<Integer, Tuple2<Iterable<String>, Iterable<String>>> result = fruitsRdd.cogroup(citiesRdd);
		 
		 System.out.println(fruitsRdd.getNumPartitions());
		 //result.saveAsTextFile("file:///D:/sample-data/cogroup-result");
		 
		 
	}
}
