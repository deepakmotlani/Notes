package com.deepak.spark.structured.streaming;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.concurrent.TimeoutException;

import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.streaming.StreamingQuery;
import org.apache.spark.sql.streaming.StreamingQueryException;

import com.deepak.spark.structured.streaming.StreamDeduplications.Ad;

public class StreamDeduplicationsWithWatermark {
	@SuppressWarnings("serial")
	public static void main(String[] args) throws StreamingQueryException, TimeoutException {
		System.setProperty("hadoop.home.dir", "D:\\spark-2.4.5-bin-hadoop2.7");
		SparkSession session = SparkSession.builder().master("local").appName("Stream Deduplications").getOrCreate();
		session.sparkContext().setLogLevel("WARN");
		Dataset<Row> ads = session.readStream().format("socket").option("host", "localhost").option("port", 9999)
				.load();

		Dataset<Ad> adDF = ads.as(Encoders.STRING()).map(new MapFunction<String, Ad>() {
			@Override
			public Ad call(String value) throws Exception {
				String[] parts = value.split(",");
				Calendar calendar = Calendar.getInstance();
				calendar.set(2020, 5, 26, Integer.parseInt(parts[2].split(":")[0]), Integer.parseInt(parts[2].split(":")[1]));
				return new Ad(Integer.parseInt(parts[0]), parts[1], new Timestamp(calendar.getTime().getTime()));
			}
		}, Encoders.bean(Ad.class));
		
		Dataset<Ad> uniqAdDF = adDF.withWatermark("adTime", "10 seconds").dropDuplicates("id", "adTime");
		
		StreamingQuery query = uniqAdDF.writeStream().outputMode("append").format("console").start();

		query.awaitTermination();
	}
}
