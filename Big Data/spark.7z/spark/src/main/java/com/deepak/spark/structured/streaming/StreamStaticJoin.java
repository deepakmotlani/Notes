package com.deepak.spark.structured.streaming;

import java.util.Arrays;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.streaming.StreamingQuery;
import org.apache.spark.sql.streaming.StreamingQueryException;

public class StreamStaticJoin {

	public static class WordMeaning {
		private String word;
		private String meaning;

		public String getWord() {
			return word;
		}

		public void setWord(String word) {
			this.word = word;
		}

		public String getMeaning() {
			return meaning;
		}

		public void setMeaning(String meaning) {
			this.meaning = meaning;
		}

		public WordMeaning(String word, String meaning) {
			super();
			this.word = word;
			this.meaning = meaning;
		}

	}

	public static void main(String[] args) throws StreamingQueryException {
		System.setProperty("hadoop.home.dir", "D:\\spark-2.4.5-bin-hadoop2.7");
		SparkSession session = SparkSession.builder().master("local").appName("Stream Static Join").getOrCreate();
		session.sparkContext().setLogLevel("WARN");
		Dataset<Row> lines = session.readStream().format("socket").option("host", "172.29.44.63").option("port", 9999)
				.load();

		Dataset<String> streamWords = lines.as(Encoders.STRING()).flatMap(x -> Arrays.asList(x.split(",")).iterator(),
				Encoders.STRING());

		JavaRDD<WordMeaning> wordMeanings = session.sqlContext().read()
				.textFile("C:\\Users\\deepak.motlani\\Desktop\\Word-Meanings").javaRDD()
				.map(x -> new WordMeaning(x.split(",")[0], x.split(",")[1]));
		
		Dataset<Row> wordMeaningRows = session.sqlContext().createDataFrame(wordMeanings, WordMeaning.class);
		
		Dataset<Row> joinedStream = streamWords.join(wordMeaningRows, wordMeaningRows.col("word").equalTo(streamWords.col("value")));
		
		StreamingQuery query = joinedStream.writeStream().outputMode("append").format("console").start();

		query.awaitTermination();

	}
}
