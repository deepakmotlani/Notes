package com.deepak.spark.sql;

import java.io.Serializable;

public class Member implements Serializable {
	private static final long serialVersionUID = 5291964644644581413L;
	
	private int id;
	private String name;
	private int age;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Member(int id, String name, int age) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
	}
	public Member() {
		super();
	}
	
}