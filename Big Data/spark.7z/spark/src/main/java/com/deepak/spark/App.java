package com.deepak.spark;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

public class App 
{
    public static void main(String[] args)
    {
        SparkConf sparkConf = new SparkConf().setAppName("First Spark App");
        JavaSparkContext sparkContext = new JavaSparkContext(sparkConf);
        
        JavaRDD<String> lines = sparkContext.textFile("file:///.//sample.txt");
        
       System.out.println("*********************" + lines.count() + "*********************");
       System.out.println("*********************" + lines.first() + "*********************");
       
       sparkContext.close();
    }
}
