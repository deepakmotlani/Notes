package com.deepak.spark.sql;

import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.api.java.UDF1;
import org.apache.spark.sql.api.java.UDF2;
import org.apache.spark.sql.expressions.UserDefinedFunction;
import org.apache.spark.sql.types.DataTypes;

import static org.apache.spark.sql.functions.udf;


public class SparkScalarUDF {
	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir", "D:\\spark-2.4.5-bin-hadoop2.7");

		SparkSession session = SparkSession.builder().master("local").appName("Java SQL UDF").getOrCreate();
		session.sparkContext().setLogLevel("WARN");

		/**
		 * 1. Random UDF, with no arg
		 */
		UserDefinedFunction random = udf(() -> Math.random(), DataTypes.DoubleType);
		
		random.asNondeterministic();
		
		session.udf().register("random", random);
		
		session.sql("SELECT random()").show();
		
		/**
		 * 2. PlusOne UDF, with 1 arg
		 */
		session.udf().register("plusOne", new UDF1<Integer, Integer>() {

			private static final long serialVersionUID = -4919120612421560090L;

			@Override
			public Integer call(Integer t1) throws Exception {
				return t1 + 1;
			}
		}, DataTypes.IntegerType);
		
		session.sql("SELECT plusOne(5)").show();
		
		/**
		 * 3. strLenPlusNumber UDF, with 2 args
		 */
		session.udf().register("strLenPlusNumber", new UDF2<String, Integer, Integer>() {

			private static final long serialVersionUID = 1L;

			@Override
			public Integer call(String t1, Integer t2) throws Exception {
				return t1.length() + t2;
			}
		}, DataTypes.IntegerType);
		
		session.sql("SELECT strLenPlusNumber('Deepak', 5)").show();
		
		/**
		 * 4. greaterThan5 UDF, use in where clause 
		 */
		session.udf().register("greaterThan5", new UDF1<Long, Boolean>() {

			private static final long serialVersionUID = 1L;

			@Override
			public Boolean call(Long t1) throws Exception {
				return t1 > 5;
			}
		}, DataTypes.BooleanType);

		session.range(1, 10).createOrReplaceTempView("test");
		session.sql("SELECT * FROM test WHERE greaterThan5(id)").show();
	}
}
