package com.deepak.spark.sql;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

public class DatasourceSchemaEvolution {
	public static class Square implements Serializable {
		private static final long serialVersionUID = -2648166188886820556L;
		private int value;
		private int square;

		public int getValue() {
			return value;
		}

		public void setValue(int value) {
			this.value = value;
		}

		public int getSquare() {
			return square;
		}

		public void setSquare(int square) {
			this.square = square;
		}

	}

	public static class Cube implements Serializable {
		private static final long serialVersionUID = 3976171290945667401L;
		private int value;
		private int cube;

		public int getValue() {
			return value;
		}

		public void setValue(int value) {
			this.value = value;
		}

		public int getCube() {
			return cube;
		}

		public void setCube(int cube) {
			this.cube = cube;
		}

	}

	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir", "D:\\spark-2.4.5-bin-hadoop2.7");

		SparkSession session = SparkSession.builder().master("local").appName("Java SQL UADF").getOrCreate();
		session.sparkContext().setLogLevel("WARN");
		
		List<Square> squares = new ArrayList<>();
		for (int value = 1; value <= 5; value++) {
		  Square square = new Square();
		  square.setValue(value);
		  square.setSquare(value * value);
		  squares.add(square);
		}

		String tablePath = "C:\\Users\\deepak.motlani\\Documents\\Notes\\Big Data\\Hive\\Practice\\schema-evolution\\test_table\\";
		// Create a simple DataFrame, store into a partition directory
		Dataset<Row> squaresDF = session.createDataFrame(squares, Square.class);
		squaresDF.write().parquet(tablePath + "key=1");
	
		List<Cube> cubes = new ArrayList<>();
		for (int value = 3; value <= 10; value++) {
		  Cube cube = new Cube();
		  cube.setValue(value);
		  cube.setCube(value * value * value);
		  cubes.add(cube);
		}

		// Create another DataFrame in a new partition directory,
		// adding a new column and dropping an existing column
		Dataset<Row> cubesDF = session.createDataFrame(cubes, Cube.class);
		cubesDF.write().parquet(tablePath + "key=2");
		
		
		Dataset<Row> mergedDF = session.read().option("mergeSchema", true).parquet(tablePath);
		mergedDF.printSchema();
		
		mergedDF.show();

	}
}
