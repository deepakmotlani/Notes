package com.deepak.spark.sql;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;

public class DatasourceSaveAsTable {
	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir", "D:\\spark-2.4.5-bin-hadoop2.7");

		SparkSession session = SparkSession.builder().master("local").appName("Java SQL UADF").getOrCreate();
		session.sparkContext().setLogLevel("WARN");

		Dataset<Row> memberDF = session.read().format("json").option("multiline", true)
				.load("C:\\Users\\deepak.motlani\\Desktop\\Members.json");

		memberDF.show();
		
		memberDF.write().option("path", "C:\\Users\\deepak.motlani\\Desktop\\spark_table").saveAsTable("members");
		
		session.table("members").filter(functions.col("id").equalTo(1)).show();
	}
}
