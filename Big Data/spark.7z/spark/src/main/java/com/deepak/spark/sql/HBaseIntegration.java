package com.deepak.spark.sql;

import java.util.Arrays;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableInputFormat;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SparkSession;

import scala.Tuple2;

public class HBaseIntegration {
	public static class Employee {
		private String city;
		private String zipcode;

		public String getCity() {
			return city;
		}

		public void setCity(String city) {
			this.city = city;
		}

		public String getZipcode() {
			return zipcode;
		}

		public void setZipcode(String zipcode) {
			this.zipcode = zipcode;
		}
		public String toString() {
			return "City: " + this.city + ", Zipcode: " + this.zipcode;
		}
	}

	public static void main(String[] args) {
		Configuration conf = HBaseConfiguration.create();
		SparkConf sparkconf = new SparkConf().setAppName("Spark HBase integration");
		SparkContext sparkContext = new SparkContext(sparkconf);
		SparkSession session = new SparkSession(sparkContext);
		JavaSparkContext jsc = new JavaSparkContext(sparkContext);
		//SQLContext sqlContext = new SQLContext(session);

		conf.addResource(new Path("/home/hadoop/hbase/hbase-2.2.5/conf/hbase-site.xml"));

		conf.set(TableInputFormat.INPUT_TABLE, "employee");
		JavaPairRDD<ImmutableBytesWritable, Result> javaPairRdd = jsc.newAPIHadoopRDD(conf, TableInputFormat.class,
				ImmutableBytesWritable.class, Result.class);
		//jsc.stop();

		// JavaHBaseContext hbaseContext = new JavaHBaseContext(jsc, conf);
		// sparkContext.newAPIHadoopRDD(conf, fClass, kClass, vClass)
		JavaRDD<Employee> employees = javaPairRdd
				.map((Function<Tuple2<ImmutableBytesWritable, Result>, Employee>) tuple -> {
					Cell cell1 = tuple._2.getColumnLatestCell(Bytes.toBytes("address"), Bytes.toBytes("city"));
					Cell cell2 = tuple._2.getColumnLatestCell(Bytes.toBytes("address"), Bytes.toBytes("zipcode"));
					Employee employee = new Employee();
					if (cell1 != null) {
						employee.setCity(new String(cell1.getValueArray()));
					}
					if (cell2 != null) {
						employee.setZipcode(new String(cell2.getValueArray()));
					}
					return employee;

				});
		employees.foreach(employee -> {
			System.out.println(employee);
		});
		//Dataset<Row> memberRows = sqlContext.createDataFrame(employees, Employee.class);

		//memberRows.show();

	}
}
