package com.deepak.spark.sql;

import java.util.Properties;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

public class JdbcMysql {
	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir", "D:\\spark-2.4.5-bin-hadoop2.7");

		SparkSession session = SparkSession.builder().master("local").appName("Jdbc Mysql").getOrCreate();
		session.sparkContext().setLogLevel("WARN");
		
		Properties connectionProperties = new Properties();
		connectionProperties.put("user", "root");
		connectionProperties.put("password", "impetus");
		
		Dataset<Row> jdbcDF = session.read()
		  .jdbc("jdbc:mysql://localhost:3306/", "test_database.test", connectionProperties);

		jdbcDF.show();
		
		jdbcDF.write()
		.option("createTableColumnTypes", "id INT, name VARCHAR(64), age INT")
		.jdbc("jdbc:mysql://localhost:3306/", "test_database.test_copy", connectionProperties);
	}
}
