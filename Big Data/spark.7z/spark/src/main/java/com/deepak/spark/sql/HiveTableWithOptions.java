package com.deepak.spark.sql;

import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SparkSession;

public class HiveTableWithOptions {

    public static void main(String[] args) {
        SparkSession session = SparkSession.builder().appName("Hive Spark App").enableHiveSupport().getOrCreate();
        session.sparkContext().setLogLevel("WARN");
        SQLContext sqlContext = session.sqlContext();
    
        sqlContext.sql("USE metastore");
        
        sqlContext.sql("CREATE TABLE IF NOT EXISTS MEMBERS_PARQUET (id INT, name STRING, age INT) "
                + "USING hive OPTIONS (fileFormat 'parquet')");

        sqlContext.sql("INSERT OVERWRITE TABLE MEMBERS_PARQUET SELECT * FROM members");
        
        sqlContext.sql("SELECT * FROM MEMBERS_PARQUET").show();

    }
}
