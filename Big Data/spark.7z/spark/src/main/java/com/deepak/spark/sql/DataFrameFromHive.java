package com.deepak.spark.sql;

import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;

public class DataFrameFromHive {
	@SuppressWarnings("serial")
	public static void main(String[] args) {
		SparkSession session = SparkSession.builder().appName("Hive Spark App").enableHiveSupport().getOrCreate();
		session.sparkContext().setLogLevel("WARN");
		SQLContext sqlContext = session.sqlContext();
	
		sqlContext.sql("USE casestudy");
		Dataset<Row> friendRows = sqlContext.sql("SELECT * FROM clickdata_paritioned_orc");
		
		/*Dataset<String> friends = friendRows.map(new MapFunction<Row, String>() {
			@Override
			  public String call(Row row) throws Exception {
			    return row.get(0) + ", " + row.get(1).toString();
			  }
		}, Encoders.STRING());
		*/
		friendRows.show();
		
		/*Dataset<Row> atulSenior = friendRows.filter(functions.array_contains(functions.col("subordinates"), "Atul"));
		atulSenior.show();*/
		
		friendRows.count();
	}
}
