package com.deepak.spark.structured.streaming;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;

import org.apache.spark.api.java.function.MapFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.catalyst.encoders.ExpressionEncoder;
import org.apache.spark.sql.streaming.StreamingQuery;
import org.apache.spark.sql.streaming.StreamingQueryException;

public class WindowedWordCount {
	public static class WordsWithTime {
		private Timestamp time;
		private String word;
		public Timestamp getTime() {
			return time;
		}
		public void setTime(Timestamp time) {
			this.time = time;
		}
		public String getWord() {
			return word;
		}
		public void setWord(String word) {
			this.word = word;
		}
		
	}

	public static void main(String[] args) throws StreamingQueryException {
		System.setProperty("hadoop.home.dir", "D:\\spark-2.4.5-bin-hadoop2.7");
		SparkSession session = SparkSession.builder().master("local").appName("Windowed Word Count").getOrCreate();
		session.sparkContext().setLogLevel("WARN");

		Dataset<String> lines = session.readStream().format("socket").option("host", "172.29.44.63").option("port", 9999)
				.load().as(Encoders.STRING());

		Dataset<WordsWithTime> words = lines.map(new MapFunction<String, WordsWithTime>() {
			@Override
			public WordsWithTime call(String row) throws Exception {
				WordsWithTime wordsWithTime = new WordsWithTime();
				String[] timeParts = row.split(",")[0].split(":");
				Calendar calendar = Calendar.getInstance();
				calendar.set(2020, 5, 25, Integer.parseInt(timeParts[0]), Integer.parseInt(timeParts[1]));
				wordsWithTime.setTime(new Timestamp(calendar.getTime().getTime()));
				wordsWithTime.setWord(row.split(",")[1]);
				return wordsWithTime;
			}
		}, ExpressionEncoder.javaBean(WordsWithTime.class));
		Dataset<Row> windowedCounts = words.groupBy(functions.window(functions.col("time"), "1 minute", "1 minute")).count();
		
		StreamingQuery query = windowedCounts.writeStream().outputMode("complete").format("console").start();

		query.awaitTermination();
	}
}
