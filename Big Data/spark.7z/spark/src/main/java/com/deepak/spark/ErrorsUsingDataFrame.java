package com.deepak.spark;

import java.util.Arrays;
import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;

public class ErrorsUsingDataFrame {
	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir", "D:\\spark-2.4.5-bin-hadoop2.7");
		SparkConf sparkConf = new SparkConf().setMaster("local").setAppName("Word Count");
		JavaSparkContext sparkContext = new JavaSparkContext(sparkConf);

		JavaRDD<String> textFile = sparkContext.textFile("file:///D:/sample-data/errors.txt");
		JavaRDD<Row> rowRDD = textFile.map(RowFactory::create);
		List<StructField> fields = Arrays.asList(DataTypes.createStructField("line", DataTypes.StringType, true));
		/*DataFrame df = sqlContext.createDataFrame(rowRDD, schema);

		DataFrame errors = df.filter(col("line").like("%ERROR%"));*/
		
	}
}
