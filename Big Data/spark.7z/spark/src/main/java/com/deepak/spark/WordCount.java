package com.deepak.spark;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.apache.spark.Accumulator;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.Optional;
import org.apache.spark.storage.StorageLevel;

import scala.Tuple2;

public class WordCount {

	public static void main(String[] args) {
		long timeNow = new Date().getTime();
		System.setProperty("hadoop.home.dir", "D:\\spark-2.4.5-bin-hadoop2.7");
		SparkConf sparkConf = new SparkConf().setMaster("local").setAppName("Word Count");
		JavaSparkContext sparkContext = new JavaSparkContext(sparkConf);
		Accumulator<Integer> accu = sparkContext.intAccumulator(0);
		JavaRDD<String> textFile = sparkContext.textFile("file:///D:/sample-data/input");
		JavaRDD<String> wordMeaning = sparkContext.textFile("file:///D:/sample-data/word-meaning");

		textFile.persist(StorageLevel.MEMORY_ONLY());
		JavaRDD<Integer> lengths = textFile.map(s -> s.length()).filter(length -> length > 13);

		lengths.saveAsTextFile("file:///D:/sample-data/lengths");

		int totalLength = lengths.reduce((a, b) -> a + b);

		System.out.println("*********************" + totalLength + "*********************");
		JavaPairRDD<String, Integer> counts = textFile.flatMap(s -> Arrays.asList(s.split(" ")).iterator())
				.mapToPair(word -> new Tuple2<>(word, 1)).reduceByKey((a, b) -> a + b);

		JavaPairRDD<String, String> wordMeaningRDD = wordMeaning.map(s -> Arrays.asList(s.split(",")))
				.mapToPair(list -> new Tuple2<>(list.get(0), list.get(1)));

		sparkContext.parallelize(Arrays.asList(1, 2, 3, 4, 5)).foreach(x -> accu.add(x));
		
		System.out.println(accu.value());
		
		List<Tuple2<String, String>> list = wordMeaningRDD.takeOrdered(2, new WordCountComparator());
		System.out.println(list);

		JavaPairRDD<String, Tuple2<Optional<String>, Integer>> joinOutput = wordMeaningRDD.rightOuterJoin(counts);

		joinOutput.saveAsTextFile("file:///D:/sample-data/join-output/");

		JavaPairRDD<String, Integer> sortedCounts = counts.sortByKey();

		sortedCounts.saveAsTextFile("file:///D:/sample-data/wordcount");

		System.out.println("*********************" + textFile.count() + "*********************");
		System.out.println("*********************" + textFile.first() + "*********************");

		sparkContext.close();
		long timeElapsed = new Date().getTime() - timeNow;
		System.out.println("Time Taken: " + timeElapsed);
	}

	public static class WordCountComparator implements Comparator<Tuple2<String, String>>, Serializable {

		@Override
		public int compare(Tuple2<String, String> o1, Tuple2<String, String> o2) {
			return o2._2().compareTo(o1._2());
		}

	}
}
