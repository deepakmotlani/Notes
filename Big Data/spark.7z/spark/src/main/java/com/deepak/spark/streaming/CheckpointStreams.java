package com.deepak.spark.streaming;

import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.Optional;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaPairDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;

import scala.Tuple2;

public class CheckpointStreams {
	static class UpdateRunningCount implements Function2<List<Integer>, Optional<Integer>, Optional<Integer>> {
		private static final long serialVersionUID = -3423927627113225402L;

		public Optional<Integer> call(List<Integer> currentBatch, Optional<Integer> currentCount) {
			int sum = currentCount.or(0);
			return Optional.of(sum + currentBatch.size());
		}
	};
	public static void main(String[] args) {
		SparkConf sparkConf = new SparkConf().setAppName("Checkpoint Stream App");
		
		JavaStreamingContext context = JavaStreamingContext.getOrCreate("hdfs://localhost:54310/spark/checkpoints", () -> {
			JavaStreamingContext jssc = new JavaStreamingContext(sparkConf, Durations.seconds(30));  
		    jssc.checkpoint("hdfs://localhost:54310/spark/checkpoints");
		    jssc.sparkContext().setLogLevel("WARN");

			JavaDStream<String> lines = jssc.socketTextStream("localhost", 7777);
			
			JavaPairDStream<String, Integer> pairDStream = lines.mapToPair(line -> new Tuple2<>(new String(line.split(",")[0]), 1));

			JavaPairDStream<String, Integer> summedCounts = pairDStream.updateStateByKey(new UpdateRunningCount());
			
			summedCounts.print();
		    return jssc;
		});
		
		
		context.start();
		try {
			context.awaitTermination();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		context.close();
	}
}
