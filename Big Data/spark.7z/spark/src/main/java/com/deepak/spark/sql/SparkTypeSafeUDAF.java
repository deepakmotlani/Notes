package com.deepak.spark.sql;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.TypedColumn;
import org.apache.spark.sql.expressions.Aggregator;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

public class SparkTypeSafeUDAF {

	public static class Average implements Serializable {
		private static final long serialVersionUID = -6281877652352857599L;
		private long sum;
		public Average(long sum, int count) {
			super();
			this.sum = sum;
			this.count = count;
		}
		private long count;
		public long getSum() {
			return sum;
		}
		public void setSum(long sum) {
			this.sum = sum;
		}
		public long getCount() {
			return count;
		}
		public void setCount(long count) {
			this.count = count;
		}
		public Average() {
			super();
		}
	}

	public static class MyAverage extends Aggregator<Member, Average, Double> {

		private static final long serialVersionUID = 1441105593178587807L;

		// Specifies the Encoder for the intermediate value type
		@Override
		public Encoder<Average> bufferEncoder() {
			return Encoders.bean(Average.class);
		}

  	    // Transform the output of the reduction
		@Override
		public Double finish(Average avg) {
			return ((double) avg.getSum() / avg.getCount());
		}

   	    // Merge two intermediate values
		@Override
		public Average merge(Average avg1, Average avg2) {
			long newSum = avg1.getSum() + avg2.getSum();
			long newCount = avg1.getCount() + avg2.getCount();
			avg1.setSum(newSum);
			avg1.setCount(newCount);
			return avg1;
		}

		// Specifies the Encoder for the final output value type
		@Override
		public Encoder<Double> outputEncoder() {
			return Encoders.DOUBLE();
		}

		// Combine two values to produce a new value. For performance, the function may modify `buffer`
		// and return it instead of constructing a new object.
		@Override
		public Average reduce(Average buff, Member member) {
			long newSum = buff.getSum() + new Long(member.getAge());
			long newCount = buff.getCount() + 1;
			buff.setSum(newSum);
			buff.setCount(newCount);
			return buff;
		}

		// A zero value for this aggregation. Should satisfy the property that any b + zero = b
		@Override
		public Average zero() {
			return new Average(0L, 0);
		}
		
	}
	
	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir", "D:\\spark-2.4.5-bin-hadoop2.7");

		SparkSession session = SparkSession.builder().master("local").appName("Java SQL UADF").getOrCreate();
		session.sparkContext().setLogLevel("WARN");
		
		List<StructField> fields = new ArrayList<>();
		fields.add(DataTypes.createStructField("id", DataTypes.IntegerType, false));
		fields.add(DataTypes.createStructField("name", DataTypes.StringType, false));
		fields.add(DataTypes.createStructField("age", DataTypes.IntegerType, false));
		
		StructType schema = DataTypes.createStructType(fields);

		Dataset<Member> members = session.sqlContext().read()
				.schema(schema)
				.csv("C:\\Users\\deepak.motlani\\Desktop\\Members").as(Encoders.bean(Member.class));
		
		members.show();
		
		MyAverage myAverage = new MyAverage();
		TypedColumn<Member, Double> avgAge = myAverage.toColumn().name("avg_age");
		
		Dataset<Double> result = members.select(avgAge);
		
		result.show();
	}
}
