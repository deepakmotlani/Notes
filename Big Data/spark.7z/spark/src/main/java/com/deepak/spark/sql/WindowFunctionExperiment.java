package com.deepak.spark.sql;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.expressions.Window;
import org.apache.spark.sql.expressions.WindowSpec;

public class WindowFunctionExperiment {

	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir", "D:\\spark-2.4.5-bin-hadoop2.7");
		SparkSession session = SparkSession.builder().master("local").appName("Window Function Experiment").getOrCreate();
		session.sparkContext().setLogLevel("WARN");
		JavaRDD<ProductCategoryRevenue> rdd = session.read().textFile("C:\\Users\\deepak.motlani\\Desktop\\Product-Category-Revenue").javaRDD().map((line) -> {
			String[] parts = line.split(",");
			ProductCategoryRevenue pcr = new ProductCategoryRevenue();
			pcr.setProduct(parts[0]);
			pcr.setCategory(parts[1]);
			pcr.setRevenue(Integer.parseInt(parts[2]));
			return pcr;
		});
		Dataset<Row> rows = session.createDataFrame(rdd, ProductCategoryRevenue.class);

		WindowSpec denseRankWindowSpec = Window.partitionBy("category").orderBy(functions.desc("revenue"));
		
		Dataset<Row> rankedRows = rows.select(functions.col("category"), functions.col("product"), functions.col("revenue"), 
				functions.dense_rank().over(denseRankWindowSpec).alias("rank"));
		
		rankedRows.where("rank <= 2").show();
		
		rows.select(functions.col("category"), functions.col("product"), functions.col("revenue"), 
			functions.max("revenue").over(denseRankWindowSpec).minus(functions.col("revenue")).alias("diff"))
			.show();
		
		rows.select(functions.col("category"), functions.col("product"), functions.col("revenue"),
			functions.sum("revenue").over(denseRankWindowSpec.rowsBetween(Window.unboundedPreceding(), 
					Window.currentRow())).alias("sum")).show();
		
		rows.select(functions.sum("revenue")).show();
		
	}
}
