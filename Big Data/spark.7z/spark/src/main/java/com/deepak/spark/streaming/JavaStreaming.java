package com.deepak.spark.streaming;

import org.apache.spark.SparkConf;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;

public class JavaStreaming {
	public static void main(String[] args) {
		SparkConf sparkConf = new SparkConf().setAppName("Streaming App");
		// Create a StreamingContext with a 1-second batch size from a SparkConf
		JavaStreamingContext jssc = new JavaStreamingContext(sparkConf, Durations.seconds(30));
		jssc.checkpoint("/home/hadoop/spark/checkpoints");
		// Create a DStream from all the input on port 7777
		JavaDStream<String> lines = jssc.socketTextStream("localhost", 7777);
		// Filter our DStream for lines with "error"
		JavaDStream<String> errorLines = lines.filter(line->  line.contains("error"));		
		// Print out the lines with errors
		errorLines.print();
		// Start our streaming context and wait for it to "finish"
		
		JavaDStream<Long> windowedErrorLines =  errorLines.countByWindow(Durations.seconds(90), Durations.minutes(1));
		windowedErrorLines.print();
		
		jssc.start();
		// Wait for the job to finish
		try {
			jssc.awaitTermination();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		jssc.close();
	}
}
