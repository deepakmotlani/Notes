package com.deepak.spark.sql;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SparkSession;

public class DataFrameFromHiveNewMetastore {
	public static void main(String[] args) {
		/**
		 * If you don't have hive-site.xml copied to your SPARK_HOME/conf directory then it will use
		 * below mentioned location spark.sql.warehouse.dir to store table data.
		 */
		SparkSession session = SparkSession.builder().appName("Hive Spark App")
			.config("spark.sql.warehouse.dir", "hdfs://localhost:54310/spark/warehouse").enableHiveSupport().getOrCreate();
		SQLContext sqlContext = new SQLContext(session);
		session.sparkContext().setLogLevel("WARN");
		
		sqlContext.sql("CREATE TABLE members (id INT, name STRING, age INT) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','");
		sqlContext.sql("LOAD DATA LOCAL INPATH '/home/hadoop/spark/Members' INTO TABLE members");
		Dataset<Row> memberRows = sqlContext.sql("SELECT * FROM members");
		
		memberRows.show();
	}
}
