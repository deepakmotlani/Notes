package com.deepak.spark.streaming;

import java.util.List;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.SequenceFileOutputFormat;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.Optional;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaPairDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;

import scala.Tuple2;

public class PairStreams {
	static class UpdateRunningCount implements Function2<List<Integer>, Optional<Integer>, Optional<Integer>> {
		public Optional<Integer> call(List<Integer> currentBatch, Optional<Integer> currentCount) {
			int sum = currentCount.or(0);
			return Optional.of(sum + currentBatch.size());
		}
	};
	public static class OutFormat extends SequenceFileOutputFormat<Text, Integer> {};
	public static void main(String[] args) {
		SparkConf sparkConf = new SparkConf().setAppName("Streaming Pair App");
		// Create a StreamingContext with a 1-second batch size from a SparkConf
		JavaStreamingContext jssc = new JavaStreamingContext(sparkConf, Durations.seconds(30));
		jssc.sparkContext().setLogLevel("WARN");
		jssc.checkpoint("/home/hadoop/spark/checkpoints");
		// Create a DStream from all the input on port 7777
		JavaDStream<String> lines = jssc.socketTextStream("localhost", 7777);
		// Filter our DStream for lines with "error"
		JavaPairDStream<String, String> pairs = lines
				.mapToPair(line -> new Tuple2(line.split(",")[0], line.split(",")[1]));
		
		// Print out the lines with errors
		pairs.print();
		// Start our streaming context and wait for it to "finish"
		JavaPairDStream<String, String> reducedPairs = pairs.reduceByKeyAndWindow((v1, v2) -> v1.concat(",").concat(v2),
				Durations.seconds(90), Durations.seconds(60));
		reducedPairs.print();

		JavaPairDStream<Text, Integer> counts = lines.mapToPair(line -> new Tuple2<>(new Text(line.split(",")[0]), 1));
		JavaPairDStream<Text, Integer> summedCounts = counts.updateStateByKey(new UpdateRunningCount());
		summedCounts.print();
		//summedCounts.saveAsHadoopFiles("/home/hadoop/spark/output", "txt", String.class, Integer.class, OutFormat.class);
		
		jssc.start();
		// Wait for the job to finish
		try {
			jssc.awaitTermination();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		jssc.close();
	}
}
