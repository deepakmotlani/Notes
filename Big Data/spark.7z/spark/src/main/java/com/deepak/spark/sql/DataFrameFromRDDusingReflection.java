package com.deepak.spark.sql;

import org.apache.spark.sql.functions;

import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SparkSession;

import scala.Tuple2;

public class DataFrameFromRDDusingReflection {
	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir", "D:\\spark-2.4.5-bin-hadoop2.7");
		SparkConf sparkConf = new SparkConf().setMaster("local").setAppName("Person Encoder Dataframe App");
		SparkContext sparkContext = new SparkContext(sparkConf);
		SparkSession session = new SparkSession(sparkContext);
		SQLContext sqlContext = new SQLContext(session);
		sparkContext.setLogLevel("WARN");

		JavaRDD<Member> membersRDD = sqlContext.read().textFile("C:\\Users\\deepak.motlani\\Desktop\\Members").javaRDD().map((line) -> {
			String[] parts = line.split(",");
			Member member = new Member(Integer.parseInt(parts[0]), parts[1], Integer.parseInt(parts[2]));
			return member;
		});
		
		JavaPairRDD<Integer, Integer> friends = sqlContext.read().textFile("C:\\Users\\deepak.motlani\\Desktop\\Member-Friends").javaRDD()
			.mapToPair(new PairFunction<String, Integer, Integer>() {

				private static final long serialVersionUID = 173221944464642627L;

				@Override
				public Tuple2<Integer, Integer> call(String line) throws Exception {
					String[] parts = line.split(",");
					return new Tuple2<>(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]));
				}
			});
		
		Dataset<Row> friendRows = sqlContext.createDataset(JavaPairRDD.toRDD(friends), Encoders.tuple(Encoders.INT(),Encoders.INT())).toDF("memberId","friendId");
		
		//Created a Data Frame, specifying the Member class using reflection.
		Dataset<Row> memberRows = sqlContext.createDataFrame(membersRDD, Member.class);
		
		memberRows.createOrReplaceTempView("members");

		Dataset<Row> kidsDF = sqlContext.sql("SELECT name FROM members WHERE age BETWEEN 1 AND 10");
		
		kidsDF.show();
		
		kidsDF.foreach(row -> System.out.println(row.getString(0)));
		kidsDF.foreach(row -> System.out.println(row.<String>getAs("name")));
		
		System.out.println("Member Friends Join");
		memberRows.join(friendRows, memberRows.col("id").equalTo(friendRows.col("memberId")), "inner")
			.select("id","name","age","friendId").orderBy(functions.desc("id")).show();			
		
		System.out.println("Member Friend Count");
		memberRows.join(friendRows, memberRows.col("id").equalTo(friendRows.col("memberId")), "left")
			.groupBy("id").agg(functions.count("friendId")).show();
		
		System.out.println("Member Friend older than 13 years");
		memberRows.filter(functions.col("age").geq(13)).show();
		
		System.out.println("Average age");
		memberRows.agg(functions.avg("age")).show();
		
		System.out.println("Collect names");
		memberRows.agg(functions.collect_list("name")).show();
		
		System.out.println("Min age");
		memberRows.agg(functions.min("age")).show();

		JavaRDD<CityState> cityStateRDD = sqlContext.read().textFile("C:\\Users\\deepak.motlani\\Desktop\\City-Year").javaRDD().map((line) -> {
			String[] parts = line.split(",");
			CityState record = new CityState();
			record.setCity(parts[0]);
			record.setState(parts[1]);
			record.setCount(Integer.parseInt(parts[2]));
			return record;
		});
		Dataset<Row> cityStateRows = sqlContext.createDataFrame(cityStateRDD, CityState.class);

		System.out.println("Cube Count");
		cityStateRows.cube("city","state").count().sort(functions.asc("city"), functions.asc("state")).show();
		
		System.out.println("Rollup Count");
		cityStateRows.rollup("city","state").count().sort(functions.asc("city"), functions.asc("state")).show();
		
		cityStateRows.filter("state == 2015").show();
	}
}
