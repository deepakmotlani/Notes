package com.deepak.spark.streaming;

import java.util.Arrays;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.Optional;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaPairDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;

import scala.Tuple2;

public class JoinStreams {
	public static void main(String[] args) {
		SparkConf sparkConf = new SparkConf().setAppName("Streaming Pair App");
		JavaStreamingContext jssc = new JavaStreamingContext(sparkConf, Durations.seconds(30));
		jssc.sparkContext().setLogLevel("WARN");
		jssc.checkpoint("/home/hadoop/spark/checkpoints");
		JavaDStream<String> lines = jssc.socketTextStream("localhost", 7777);
		JavaDStream<String> meanings = jssc.socketTextStream("localhost", 8888);
		
		JavaPairDStream<String, String> linesPair = lines.mapToPair(line -> new Tuple2(line.split(",")[0], line.split(",")[1]));
		JavaPairDStream<String, String> meaningsPair = meanings.mapToPair(line -> new Tuple2(line.split(",")[0], line.split(",")[1]));
		
		JavaPairDStream<String, Tuple2<String, String>> joinedData = linesPair.join(meaningsPair);
		
		joinedData.print();
		
		JavaPairDStream<String, String> windowedLines = linesPair.window(Durations.seconds(60), Durations.seconds(60));
		JavaPairDStream<String, String> windowedMeanings = meaningsPair.window(Durations.seconds(60), Durations.seconds(60));
		JavaPairDStream<String, Tuple2<String, Optional<String>>> joinedWindowData = windowedLines.leftOuterJoin(windowedMeanings);
		
		joinedWindowData.print();
		
		//JavaPairRDD<String, String> dataSet = jssc.sparkContext().parallelizePairs(Arrays.asList(new Tuple2<String, String>("hi", "coming from dictionary")));
		
		jssc.start();
		try {
			jssc.awaitTermination();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		jssc.close();
	}
}
