package com.deepak.spark.sql;

import java.util.ArrayList;
import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

public class DataFrameFromRDDProgramatically {

	
	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir", "D:\\spark-2.4.5-bin-hadoop2.7");
		SparkConf sparkConf = new SparkConf().setMaster("local").setAppName("Person Encoder Dataframe App");
		SparkContext sparkContext = new SparkContext(sparkConf);
		SparkSession session = new SparkSession(sparkContext);
		SQLContext sqlContext = new SQLContext(session);
		sparkContext.setLogLevel("WARN");

		JavaRDD<String> strings = sparkContext.textFile("C:\\Users\\deepak.motlani\\Desktop\\Members", 1).toJavaRDD();
		
		JavaRDD<Row> rowRDD = strings.map(line -> {
			String[] attributes = line.split(",");
		    return RowFactory.create(Integer.parseInt(attributes[0]), attributes[1], Integer.parseInt(attributes[2]));
		});
		
		List<StructField> fields = new ArrayList<StructField>();
		fields.add(DataTypes.createStructField("id", DataTypes.IntegerType, false));
		fields.add(DataTypes.createStructField("name", DataTypes.StringType, false));
		fields.add(DataTypes.createStructField("age", DataTypes.IntegerType, false));
		
		StructType schema = DataTypes.createStructType(fields);
		
		// Creating Data Frame, by programtically spicfying the schema.
		Dataset<Row> memberRows = sqlContext.createDataFrame(rowRDD, schema);
		
		memberRows.createOrReplaceTempView("members");

		Dataset<Row> kidsDF = sqlContext.sql("SELECT name FROM members WHERE age BETWEEN 1 AND 10");
		
		kidsDF.show();
		
		kidsDF.foreach(row -> System.out.println(row.getString(0)));
		kidsDF.foreach(row -> System.out.println(row.<String>getAs("name")));

	}
}
