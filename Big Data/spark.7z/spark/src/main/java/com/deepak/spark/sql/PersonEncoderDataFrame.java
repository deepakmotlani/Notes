package com.deepak.spark.sql;

import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;

public class PersonEncoderDataFrame {
	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir", "D:\\spark-2.4.5-bin-hadoop2.7");
		Encoder<Member> memberEncoder = Encoders.bean(Member.class);
		SparkConf sparkConf = new SparkConf().setMaster("local").setAppName("Person Encoder Dataframe App");
		SparkContext sparkContext = new SparkContext(sparkConf);
		SparkSession session = new SparkSession(sparkContext);
		SQLContext sqlContext = new SQLContext(session);
		sparkContext.setLogLevel("WARN");

		Dataset<Member> members = sqlContext.read().option("multiline", true).json("C:\\Users\\deepak.motlani\\Desktop\\Members.json").as(memberEncoder);
		
		members.show();
		
		//members.select(functions.col(""))
		
	}
}
