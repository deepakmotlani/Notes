package com.deepak.spark.sql;

import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.sql.Column;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SparkSession;

public class QueryJsonData {
	public static void main(String[] args) {
		System.setProperty("hadoop.home.dir", "D:\\spark-2.4.5-bin-hadoop2.7");

		SparkConf sparkConf = new SparkConf().setMaster("local").setAppName("Spark SQL App");
		SparkContext sparkContext = new SparkContext(sparkConf);
		SparkSession session = new SparkSession(sparkContext);
		SQLContext sqlContext = new SQLContext(session);
		sparkContext.setLogLevel("WARN");

		Dataset<Row> members = sqlContext.read().option("multiline", true).json("C:\\Users\\deepak.motlani\\Desktop\\Members.json");
		
		System.out.println("All members");
		members.show();
		
		System.out.println("Schema");
		members.printSchema();
		
		System.out.println("Name column");
		members.select("name").show();
		
		System.out.println("Filter id > 1");
		members.filter(new Column("id").gt("1")).show();
		
		System.out.println("Group By Age");
		members.groupBy(new Column("age")).count().show();
		
		System.out.println("Distinct Ages");
		members.select(new Column("age")).distinct().show();
		
		members.createOrReplaceTempView("members");

		Dataset<Row> namesDF = sqlContext.sql("SELECT * FROM members WHERE id = 1");
		
		namesDF.show();
	}
}
