package movielens.mapper;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import movielens.domain.TextPair;

public class MovieMapper extends Mapper<LongWritable, Text, TextPair, Text> {
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {		
		String valueString = value.toString();
		String[] singleMovieData = valueString.split(",");
		System.out.println(singleMovieData[0]);
		context.write(new TextPair(singleMovieData[0], "0"), new Text(singleMovieData[1]));
	}
}