package movielens.join;

import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;

import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import movielens.domain.TextPair;
import movielens.groupcomparator.KeyComparator;
import movielens.mapper.MovieMapper;
import movielens.mapper.RatingsMapper;
import movielens.partitioner.KeyPartitioner;
import movielens.reducer.MovieRatingsReducer;

public class JoinMovieNameWithRatingCount extends Configured implements Tool {
	@Override
	public int run(String args[]) throws Exception {
		JobConf jobConfiguration = new JobConf(getClass());
		Job job = Job.getInstance(jobConfiguration, "Movie Name Rating Count");		

		Path movieInputPath = new Path(args[1]);
		Path ratingInputPath = new Path(args[2]);
		Path outputPath = new Path(args[3]);

		MultipleInputs.addInputPath(job, movieInputPath, TextInputFormat.class, MovieMapper.class);
		MultipleInputs.addInputPath(job, ratingInputPath, TextInputFormat.class, RatingsMapper.class);
		FileOutputFormat.setOutputPath(job, outputPath);

		job.setPartitionerClass(KeyPartitioner.class);
		job.setGroupingComparatorClass(KeyComparator.class);

		job.setMapOutputKeyClass(TextPair.class);
		job.setOutputKeyClass(Text.class);
		job.setReducerClass(MovieRatingsReducer.class);

		return job.waitForCompletion(true) ? 0 : 1;
	}

	public static void main(String[] args) throws Exception {
		int exitCode = ToolRunner.run(new JoinMovieNameWithRatingCount(), args);
		System.exit(exitCode);
	}
}