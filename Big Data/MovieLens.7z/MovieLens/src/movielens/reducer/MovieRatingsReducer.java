package movielens.reducer;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import movielens.domain.TextPair;

public class MovieRatingsReducer extends Reducer<TextPair, Text, Text, LongWritable> {
	public void reduce(TextPair key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
		Iterator<Text> iterator = values.iterator();
		Text movieName = new Text(iterator.next());
		System.out.println(movieName);		
		
		int ratingsCount = 0;
		while (iterator.hasNext()) {			
			ratingsCount++;
			iterator.next();
		}
		System.out.println(ratingsCount);
		context.write(movieName, new LongWritable(ratingsCount));
	}
}
