package movielens.groupcomparator;

import org.apache.hadoop.io.WritableComparator;

import movielens.domain.TextPair;

public class KeyComparator extends WritableComparator {	

	public int compare(Object a, Object b) {
		System.out.println("A: " + a + ", B: " + b);
		if (a instanceof TextPair && b instanceof TextPair) {
			return ((TextPair) a).getFirst().compareTo(((TextPair) b).getFirst());
		}
		return super.compare(a, b);
	}
}
