package movielens.partitioner;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

import movielens.domain.TextPair;

public class KeyPartitioner extends Partitioner<TextPair, Text>{

	@Override
	public int getPartition(TextPair key, Text value, int numberOfPartitions) { 
		System.out.println("Key: " + key);
		return (key.getFirst().hashCode() * Integer.MAX_VALUE) % numberOfPartitions;
	}

}
