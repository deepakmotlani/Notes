package mapper;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class ServiceIdPincodeMapper extends Mapper<Object, Text, Text, Text>{
	public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
		String[] valueArray = value.toString().split(",");
		
		Text outKey = new Text(valueArray[0]);
		Text outValue = new Text(valueArray[1]);
		
		context.write(outKey, outValue);
	}
}
