package mapper;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.join.TupleWritable;

public class JoinMapper extends MapReduceBase implements Mapper<Text, TupleWritable, Text, Text> {
	public void map(Text foreignKey, TupleWritable tuples, OutputCollector<Text, Text> output, Reporter reporter) throws IOException {
		System.out.println(foreignKey);
		System.out.println((Text) tuples.get(0));
		System.out.println((Text) tuples.get(1));
		output.collect((Text) tuples.get(0), (Text) tuples.get(1));
	}
}
