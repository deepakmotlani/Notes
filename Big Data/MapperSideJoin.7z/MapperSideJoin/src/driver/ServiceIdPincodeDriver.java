package driver;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

import mapper.ServiceIdPincodeMapper;

public class ServiceIdPincodeDriver {
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		Configuration conf = new Configuration();
		Job sampleJob = Job.getInstance(conf);
		sampleJob.setJarByClass(ServiceIdPincodeDriver.class);		
		TextInputFormat.setInputPaths(sampleJob, new Path(args[0]));
		TextOutputFormat.setOutputPath(sampleJob, new Path(args[1]));
		sampleJob.setOutputKeyClass(Text.class);
		sampleJob.setOutputValueClass(Text.class);
		sampleJob.setMapperClass(ServiceIdPincodeMapper.class);
		sampleJob.setNumReduceTasks(0);		
		
		sampleJob.waitForCompletion(true);
	}
}
