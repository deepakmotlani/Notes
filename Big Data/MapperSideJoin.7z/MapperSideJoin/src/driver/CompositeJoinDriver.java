package driver;

import java.io.IOException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.KeyValueTextInputFormat;
import org.apache.hadoop.mapred.RunningJob;
import org.apache.hadoop.mapred.TextOutputFormat;
import org.apache.hadoop.mapred.join.CompositeInputFormat;

import mapper.JoinMapper;

public class CompositeJoinDriver {
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		JobConf job = new JobConf("Composite Join");

		job.setJarByClass(CompositeJoinDriver.class);
		job.setInputFormat(CompositeInputFormat.class);
		job.set("mapred.join.expr",
				CompositeInputFormat.compose("outer", KeyValueTextInputFormat.class, args[0], args[1]));

		TextOutputFormat.setOutputPath(job, new Path(args[2]));

		job.setMapperClass(JoinMapper.class);

		job.setNumReduceTasks(0);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

		RunningJob runjob = JobClient.runJob(job);

		while (!runjob.isComplete()) {
			Thread.sleep(1000);
		}
		System.exit(runjob.isSuccessful() ? 0 : 1);
	}
}
