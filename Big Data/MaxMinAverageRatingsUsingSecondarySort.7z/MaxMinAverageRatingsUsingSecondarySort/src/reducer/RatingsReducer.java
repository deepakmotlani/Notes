package reducer;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import domain.UserRating;

public class RatingsReducer extends Reducer<UserRating, FloatWritable, LongWritable, Text> {
	public void reduce(UserRating key, Iterable<FloatWritable> values, Context context) throws IOException, InterruptedException {
		Iterator<FloatWritable> itr = values.iterator();
		float min = 0, max = 0, average = 0;
		FloatWritable current = null;		
		min = itr.next().get();
		while(itr.hasNext()) {
			current = itr.next();			
		}
		max = current.get();
		average = (min + max)/2;		
		Text outValue = new Text("Min: " + min + ", Max: " + max + ", Average: " + average);
		System.out.println(key + ": " + outValue);
		context.write(key.getFirst(), outValue);		
	}
}
