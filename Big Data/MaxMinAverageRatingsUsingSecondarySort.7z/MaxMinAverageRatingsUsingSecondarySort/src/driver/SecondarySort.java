package driver;

import java.io.IOException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import comparator.GroupComparator;
import comparator.KeyComparator;
import domain.UserRating;
import reducer.RatingsReducer;
import mapper.RatingsMapper;
import partitioner.KeyPartitioner;

public class SecondarySort {
	public static void main(String[] args) throws IOException, InterruptedException, ClassNotFoundException {		
		JobConf jobConf = new JobConf();
	    Job job = Job.getInstance(jobConf, "Max Min Average Ratings");
	    
	    job.setJarByClass(SecondarySort.class);
	    job.setMapperClass(RatingsMapper.class);
	    job.setReducerClass(RatingsReducer.class);
	    job.setPartitionerClass(KeyPartitioner.class);
	    job.setSortComparatorClass(KeyComparator.class);
	    job.setGroupingComparatorClass(GroupComparator.class);
	    
	    job.setMapOutputKeyClass(UserRating.class);
	    job.setMapOutputValueClass(FloatWritable.class);
	    job.setOutputKeyClass(LongWritable.class);
	    job.setOutputValueClass(Text.class);
	    
	    FileInputFormat.addInputPath(job, new Path(args[1]));
	    FileOutputFormat.setOutputPath(job, new Path(args[2]));
	    
	    System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}
