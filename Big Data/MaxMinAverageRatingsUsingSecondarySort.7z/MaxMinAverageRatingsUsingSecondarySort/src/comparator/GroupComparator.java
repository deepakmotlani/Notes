package comparator;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

import domain.UserRating;

public class GroupComparator extends WritableComparator {
	
	protected GroupComparator() {
		super(UserRating.class, true);
	}
	
	@Override
	public int compare(WritableComparable first, WritableComparable second) {
		UserRating userRating1 = (UserRating) first;
		UserRating userRating2 = (UserRating) second;
		return userRating1.getFirst().compareTo(userRating2.getFirst());		
	}
}
