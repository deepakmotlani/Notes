package comparator;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

import domain.UserRating;

public class KeyComparator extends WritableComparator {
	
	protected KeyComparator() {
		super(UserRating.class, true);
	}
	
	@Override
	public int compare(WritableComparable first, WritableComparable second) {
		UserRating userRating1 = (UserRating) first;
		UserRating userRating2 = (UserRating) second;
		return userRating1.compareTo(userRating2);		
	}
}
