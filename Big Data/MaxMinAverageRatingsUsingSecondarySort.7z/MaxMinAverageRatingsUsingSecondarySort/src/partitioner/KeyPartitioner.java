package partitioner;

import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.mapreduce.Partitioner;

import domain.UserRating;

public class KeyPartitioner extends Partitioner<UserRating, FloatWritable>{

	@Override
	public int getPartition(UserRating key, FloatWritable value, int numberOfPartitions) {
		return (int)(key.getFirst().get() * 127) % numberOfPartitions;
	}

}
