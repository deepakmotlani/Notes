package mapper;

import java.io.IOException;

import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class RatingsMapper extends Mapper<LongWritable, Text, LongWritable, FloatWritable> {
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		String[] ratingRecord = value.toString().split(",");
		String userId = ratingRecord[0];
		if(userId.equalsIgnoreCase("userId")) {
			return;
		}
		LongWritable outKey = new LongWritable(Long.parseLong(userId));
		FloatWritable outValue = new FloatWritable(Float.parseFloat(ratingRecord[2]));
		System.out.println(outKey + ": " + outValue);
		context.write(outKey, outValue);
	}
}
