package combiner;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class RatingsReducer extends Reducer<LongWritable, FloatWritable, LongWritable, Text> {
	public void reduce(LongWritable key, Iterable<FloatWritable> values, Context context) throws IOException, InterruptedException {
		Iterator<FloatWritable> itr = values.iterator();
		float min = 0, max = 0, average = 0;
		FloatWritable current = null;
		while(itr.hasNext()) {
			current = itr.next();
			if(min == 0 && max == 0) {
				max = current.get(); 
				min = current.get();
			} else {
				if(min > current.get()) {
					min = current.get();
				}
				if(max < current.get()) {
					max = current.get();
				}
			}
		}
		average = (min + max)/2;		
		Text outValue = new Text("Min: " + min + ", Max: " + max + ", Average: " + average);
		System.out.println(key + ": " + outValue);
		context.write(key, outValue);		
	}
}
