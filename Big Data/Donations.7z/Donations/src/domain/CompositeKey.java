package domain;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.WritableComparable;

public class CompositeKey implements WritableComparable<CompositeKey>{

	private String state;
	private String city;
	private int totalDonation;
	
	public CompositeKey() {
		
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getTotalDonation() {
		return totalDonation;
	}
	public void setTotalDonation(int totalDonation) {
		this.totalDonation = totalDonation;
	}
	public CompositeKey(String state, String city, int totalDonation) {
		super();
		this.state = state;
		this.city = city;
		this.totalDonation = totalDonation;
	}
	@Override
	public void readFields(DataInput in) throws IOException {
		state = in.readUTF().trim();
		city = in.readUTF().trim();
		totalDonation = in.readInt();
		
	}
	@Override
	public void write(DataOutput out) throws IOException {
		out.writeUTF(state);
		out.writeUTF(city);
		out.writeFloat(totalDonation);
		
	}
	@Override
	public int compareTo(CompositeKey o) {
		int stateCmp = state.toLowerCase().compareTo(o.state.toLowerCase());
		if (stateCmp != 0) {
			return stateCmp;
		} else {
			int cityCmp = city.toLowerCase().compareTo(o.city.toLowerCase());
			if (cityCmp != 0) {
				return cityCmp;
			} else {
				return Integer.compare(totalDonation, o.totalDonation);
			}
		}
	}
	public String toString() {
		return this.getState() + " " + this.getCity() + " " + this.getTotalDonation();
	}
}
