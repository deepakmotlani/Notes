package domain;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.WritableComparable;

public class DonationRecord implements WritableComparable<DonationRecord> {
	private String individualName;
	private String city;
	private String state;	
	private int amount;
	
	public DonationRecord() {
		
	}
	public DonationRecord(String individualName, String city, String state, int amount) {
		super();
		this.individualName = individualName;
		this.city = city;
		this.state = state;
		this.amount = amount;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getIndividualName() {
		return individualName;
	}
	public void setIndividualName(String individualName) {
		this.individualName = individualName;
	}
	public String toString() {
		return this.individualName + " " + this.state + " " + this.city + " " + this.amount;
	}
	@Override
	public void readFields(DataInput in) throws IOException {
		individualName = in.readUTF();
		city = in.readUTF();
		state = in.readUTF();
		amount = in.readInt();
		
	}
	@Override
	public void write(DataOutput out) throws IOException {
		out.writeUTF(individualName);
		out.writeUTF(city);
		out.writeUTF(state);
		out.writeInt(amount);
		
	}
	@Override
	public int compareTo(DonationRecord o) {
		return this.individualName.compareTo(o.getIndividualName());
	}
}
