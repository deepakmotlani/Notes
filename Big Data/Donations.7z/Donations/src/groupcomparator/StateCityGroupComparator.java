package groupcomparator;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

import domain.CompositeKey;

public class StateCityGroupComparator extends WritableComparator {
	public StateCityGroupComparator() {
        super(CompositeKey.class, true);
    }
    
    @SuppressWarnings("rawtypes")
    @Override
    public int compare(WritableComparable wc1, WritableComparable wc2) {
        CompositeKey key1 = (CompositeKey) wc1;
        CompositeKey key2 = (CompositeKey) wc2;
        int stateComparison = key1.getState().compareTo(key2.getState());
        return stateComparison == 0 ? key1.getCity().compareTo(key2.getCity()) : stateComparison;
    }
}
