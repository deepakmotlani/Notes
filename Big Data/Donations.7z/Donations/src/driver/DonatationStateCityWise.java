package driver;

import java.io.IOException;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import domain.CompositeKey;
import domain.DonationRecord;
import groupcomparator.StateCityGroupComparator;
import mapper.DonationMapper;
import partitioner.CompositeKeyPartitioner;
import reducer.DonationReducer;

public class DonatationStateCityWise {
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		JobConf jobConf = new JobConf();
		Job job = Job.getInstance(jobConf, "Donation State City Wise");
		
		job.setJarByClass(DonatationStateCityWise.class);
		
		//Mapper Configurations
	    job.setMapperClass(DonationMapper.class);
	    job.setMapOutputKeyClass(CompositeKey.class);
	    job.setMapOutputValueClass(DonationRecord.class);
	    
	    //Reducer Configurations
	    job.setReducerClass(DonationReducer.class);	    
	    job.setOutputKeyClass(Text.class);
	    job.setOutputValueClass(LongWritable.class);
	    
	    job.setPartitionerClass(CompositeKeyPartitioner.class);
	    job.setGroupingComparatorClass(StateCityGroupComparator.class);
	    
	    FileInputFormat.addInputPath(job, new Path(args[0]));
	    FileOutputFormat.setOutputPath(job, new Path(args[1]));
	    
	    System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}
