package partitioner;

import org.apache.hadoop.mapreduce.Partitioner;

import domain.CompositeKey;
import domain.DonationRecord;

public class CompositeKeyPartitioner extends Partitioner<CompositeKey, DonationRecord>{

	@Override
	public int getPartition(CompositeKey key, DonationRecord donationRecord, int numberOfPartitions) {
		System.out.println("numberOfPartitions: " + numberOfPartitions);
		return Math.abs(key.getState().hashCode() & Integer.MAX_VALUE) % numberOfPartitions;
	}

}
