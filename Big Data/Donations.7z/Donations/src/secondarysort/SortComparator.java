package secondarysort;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

import domain.CompositeKey;

public class SortComparator extends WritableComparator {

	public SortComparator() {
        super(CompositeKey.class, true);
    }
	    
    @SuppressWarnings("rawtypes")
    @Override
    public int compare(WritableComparable wc1, WritableComparable wc2) {
        CompositeKey key1 = (CompositeKey) wc1;
        CompositeKey key2 = (CompositeKey) wc2;
        
        int stateCmp = key1.getState().toLowerCase().compareTo(key2.getState().toLowerCase());
        if (stateCmp != 0) {
            return stateCmp;
        } else {
            int cityCmp = key1.getCity().toLowerCase().compareTo(key2.getCity().toLowerCase());
            if (cityCmp != 0) {
                return cityCmp;
            } else {
                return -1 * Integer.compare(key1.getTotalDonation(), key2.getTotalDonation());
            }
        }
    }
}
