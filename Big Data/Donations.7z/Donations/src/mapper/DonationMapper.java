package mapper;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import domain.CompositeKey;
import domain.DonationRecord;

public class DonationMapper extends Mapper<Object, Text, CompositeKey, DonationRecord> {
	
	@Override
	public void map(Object key, Text donationRecord, Context context) throws IOException, InterruptedException {
		System.out.println(key);
		String[] donationRecordDetails = donationRecord.toString().split(",");
		String columnValue = donationRecordDetails[0];
		if(columnValue.equalsIgnoreCase("IndividualName")) {
			return;
		}
		CompositeKey compositeKey = new CompositeKey(donationRecordDetails[2].trim(), donationRecordDetails[1].trim(), Integer.parseInt(donationRecordDetails[3].trim()));
		System.out.println(donationRecord);
		context.write(compositeKey, new DonationRecord(donationRecordDetails[0].trim(), donationRecordDetails[1].trim(), donationRecordDetails[2].trim(), Integer.parseInt(donationRecordDetails[3].trim())));
	}
}
