package reducer;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import domain.CompositeKey;
import domain.DonationRecord;

public class DonationReducer extends Reducer<CompositeKey, DonationRecord, Text, LongWritable>{
	
	@Override
	public void reduce(CompositeKey key, Iterable<DonationRecord> values, Context context) throws IOException, InterruptedException {
		System.out.println(key);
		Iterator<DonationRecord> iterator = values.iterator();
		
		int totalDonation = 0;
		while (iterator.hasNext()) {	
			int amount = iterator.next().getAmount();
			System.out.println(amount);
			totalDonation += amount;
		}
		System.out.println(totalDonation);
		context.write(new Text(key.getState() + " " + key.getCity()), new LongWritable(totalDonation));
	}
}
